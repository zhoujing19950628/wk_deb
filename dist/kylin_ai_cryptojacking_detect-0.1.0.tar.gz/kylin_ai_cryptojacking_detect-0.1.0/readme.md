# 挖矿木马实时检测项目
- 三层策略，通过sudo python3 cryptojacking_detect.py -m 进行启动检测。